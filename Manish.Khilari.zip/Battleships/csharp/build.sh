#!/bin/bash

dotnet clean && dotnet build
