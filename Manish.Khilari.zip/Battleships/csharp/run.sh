#!/bin/bash

dotnet bin/Debug/netcoreapp2.1/Akuna.Battleships.dll $1
