#!/bin/bash

java -cp target/battleships-1.0.0.jar akuna.battleships.Main $1
