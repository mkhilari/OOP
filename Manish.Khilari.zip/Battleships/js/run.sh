#!/bin/bash

node battleships.js $1
