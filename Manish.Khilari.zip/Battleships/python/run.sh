#!/bin/bash

python3 battleships.py $1
